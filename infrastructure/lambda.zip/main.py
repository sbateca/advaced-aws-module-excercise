def handler(event, context):
    return {
        "status_code": 200,
        "message": "The backend is working"
    }
